import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

class Assembler{
    private final Opcodes OpCode;
    private SymbolTable SymTable;
    private MacroTable MacTable;
    private LiteralTable LitTable;
    private OpCodeTable OpTable;

    Assembler(){
        OpCode = new Opcodes();
        SymTable = new SymbolTable();
        MacTable = new MacroTable();
        LitTable = new LiteralTable();
        OpTable = new OpCodeTable();
    }

    void passOne(File Code) throws FileNotFoundException{
        int locationCounter = 0;
        Scanner sn = new Scanner(Code);
        while(sn.hasNextLine()) {
            String line = sn.nextLine();
            if(line == "\n" || line == " " || line == null || line.isEmpty() || line.isEmpty()){ // if it is a blank line
                continue;
            }
            if(line.toUpperCase().contains("MACRO")){
                String[] split = line.split("\\s");
                String MacroName = split[1];
                int size=0;
                int address = locationCounter;
                String def = "";
                line = sn.nextLine();
                while(line.toUpperCase().contains("MEND")==false) {
                    def+=line+"\n";
                    line = sn.nextLine();
                    size+=12;
                }
                ArrayList<Object> Macro = new ArrayList<Object>();
                Macro.add(MacroName);
                Macro.add(address);
                Macro.add(size);
                Macro.add(def);
                MacTable.add(Macro);
                line = sn.nextLine();
                
            }
            System.out.println(line);
            String[] split = line.split("\\s+");  // splitting the lines in the code by spaces
            
            if ((!split[0].isEmpty() && split[0] != " " && split[0].charAt(0) != '/') || split[0].isEmpty()){    //This is not a comment in the code, taking comments as lines starting with /
//                    split[0] can be a space " " but this would not be a label but an opcode instruction
               
                try{
                    if(!split[0].isEmpty()){ // first character is not empty
                        
                        if(split[0].substring(split[0].length() - 1).equals(":")){ // label is present
                            ArrayList<Object> labelType = new ArrayList<Object>();
                            labelType.add(split[0].substring(0, split[0].length()-1));  // adding symbol
                            int offset = locationCounter;
                            labelType.add(offset); //  adding offset
                            labelType.add("Label");  // the type is label
                            labelType.add(" ");  // value is null
                            labelType.add(" ");  // size is null //******CHECK******
                            SymTable.add(labelType); // add to symbol table
                            ArrayList<Object> opcodeType = new ArrayList<Object>();
                            if(!OpCode.valid(split[1])) {
                                if(!MacTable.valid(split[1])) {
                                    
                                    ///////////////////////////////////////////             ERROR   HANDLED         //////////////////////////////////////
                                    System.out.println(" ERROR : " + split[1] +" IS NEITHER AN OPCODE NOT A MACRO!");
                                    return;
                                }
                                else {
                                    locationCounter+=MacTable.getSize(split[1]);
                                }
                            }
                            else {
                                opcodeType.add(split[1]); // adding opcode
                                try {
                                    opcodeType.add(split[2]); // adding operand 1
                                    if(split[2].charAt(0) == '\''){
                                        // this is a literal. Literal is of the form '=[value]'
                                        ArrayList<Object> literalType = new ArrayList<Object>();
                                        literalType.add(""); // name
                                        literalType.add(locationCounter); // address
                                        String val_str = split[2].replace("\'", "");
                                        val_str = split[2].replace("=", "");
                                        int value = Integer.parseInt(val_str);
                                        literalType.add(value); // value
                                        literalType.add(4);  // size  //******CHECK******
                                    }
                                }
                                catch(ArrayIndexOutOfBoundsException e){
                                    // in case there is no operand
                                }
                                OpTable.add(opcodeType); // add to opcode table
                                locationCounter += 12;   //******CHECK******
                            }
                        }
                        
                        else{ // label is not present
                            ArrayList<Object> opcodeType = new ArrayList<Object>();
                            opcodeType.add(split[0]); // adding opcode
                            if(!OpCode.valid(split[0])) {
                                if(!MacTable.valid(split[0])) {
                                    System.out.println(" ERROR : "+split[0] +" IS NEITHER AN OPCODE NOT A MACRO!");
                                    return;
                                }
                                else {
                                    locationCounter+=MacTable.getSize(split[0]);
                                }
                            }
                            else {
                                try {
                                    opcodeType.add(split[1]); // adding operand 1
                                    if(split[1].charAt(0) == '\''){
                                        // this is a literal. Literal is of the form '=[value]'
                                        ArrayList<Object> literalType = new ArrayList<Object>();
                                        literalType.add(""); // name
                                        literalType.add(locationCounter); // address
                                        String val_str = split[2].replace("\'", "");
                                        val_str = split[2].replace("=", "");
                                        int value = Integer.parseInt(val_str);
                                        literalType.add(value); // value
                                        literalType.add(4);  // size  //******CHECK******
                                    }
                                }
                                catch(StringIndexOutOfBoundsException e){
                                    // in case there is no operand
                                }
                            
                                OpTable.add(opcodeType); // add to opcode table
                                locationCounter += 12;   //******CHECK******
                            }
                        }
                    }
                }
                catch(IndexOutOfBoundsException e){
                    
                }
            }
        }
        System.out.print("Symbol Table");
        SymTable.printTable();
        System.out.print("Literal Table");
        LitTable.printTable();
        System.out.print("Opcode Table");
        OpTable.printTable();
        System.out.println("Macro Table");
        MacTable.printTable();
        sn.close();
    }
    void passTwo(File Code, File Output) throws IOException{
        FileWriter fw = new FileWriter(Output);
        int locationCounter = 0;
        String operand;
        String OPCode;
        Scanner sn = new Scanner(Code);
        while(sn.hasNextLine()) {
            String address, opcodeBinary, operandBinary;
            String line = sn.nextLine();
            if(line == "\n" || line == " " || line == null || line.isEmpty() || line.isEmpty()){ // if it is a blank line
                continue;
            }
            try {
                
                String[] split = line.split("\\s+");  // splitting the lines in the code by spaces
                if ((!split[0].isEmpty() && split[0] != " " && split[0].charAt(0) != '/') || split[0].isEmpty()){    //This is not a comment in the code, taking comments as lines starting with /
    //              split[0] can be a space " " but this would not be a label but an opcode instruction
                    if(!split[0].isEmpty()){ // first character is not empty
                        
                      //Getting Address
                      address = Integer.toBinaryString(locationCounter);
                      while(address.length()<6) {
                          address = "0"+address;
                      }
                      
                      //Getting Opcode and Operand when label is present
                      if(split[0].substring(split[0].length() - 1).equals(":")){ // label is present
                          OPCode = split[1];
                          operand = split[2]; 
                      }
                      
                      //Getting Opcode and Operand when label is not present;
                      else{ // label is not present
                          OPCode = split[0];
                          operand = split[1];
                      }
                      opcodeBinary = OpCode.getBitcode(OPCode);
                      int val = 0;
                      try {
                          val = Integer.parseInt(operand);
                      }
                      catch(Exception e) {
                          val = SymTable.findAddress(operand);
                      }
                      finally {
                          operandBinary = Integer.toBinaryString(val);
                      }
                      fw.write(locationCounter+" "+ OPCode +" " + val+"\n");
                      fw.write(address+" "+opcodeBinary+" "+operandBinary+"\n");
                      locationCounter += 12;   //******CHECK******
                  }
                }
            }
            catch(IndexOutOfBoundsException e) {
                System.out.println("Came here");
                System.out.println(line);
                if(line.contains("STP")) {
                    address = Integer.toBinaryString(locationCounter);
                    opcodeBinary = OpCode.getBitcode("STP");
                    fw.write(locationCounter+" "+"STP\n");
                    fw.write(address+" "+opcodeBinary+"\n");
                    locationCounter++;
                }
            }
      }
      fw.close();
      sn.close();
  }
}
            
public class Main {

    public static void main(String[] args) throws IOException {
        // TODO Auto-generated method stub
        Assembler A = new Assembler();
        File Code = new File("C:\\Users\\Harsh Kumar Sethi\\Desktop\\input.txt");
        File Output = new File("C:\\\\Users\\\\Harsh Kumar Sethi\\\\Desktop\\\\output.txt");
        try {
//            A.Assemble(Code);
            A.passOne(Code);
            A.passTwo(Code, Output);
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            System.out.println("Wrong File: Cannot Assemble");
            e.printStackTrace();
        }
    }
}